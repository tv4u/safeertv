World News Live add-on for XBMC
==========================================

This plugin provides streams of various news channels and allows you to watch them in XBMC.

Some contents are geo-restricted.


